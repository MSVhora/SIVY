<!DOCTYPE html>
<html itemscope="" itemtype="http://schema.org/Website" lang="en">
<head>
<meta content="text/html; charset=utf-8" http-equiv="content-type">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Logo Design Cost India | Logo Design Price Estimate</title>
<link rel="stylesheet" href="includes/bootstrap.min.css">
<meta name="description" content="Looking for a cost estimate for your logo? We have over 16 years experience in developing creative logo designs. For a price quote, visit our page.">
<meta name="abstract" content="Logo Design Cost, Logo Design Price Estimate, Branding Services">
<meta name="Author" content="Niyati Technologies Private Limited">
<meta name="copyright" content="Niyati Technologies Private Limited">
<meta name="Distribution" content="global">
<meta name="robots" content="index, follow">
<meta name="googlebot" content="index, follow">
<meta itemprop="name" content="Logo Design Cost, Logo Design Price Estimate, Branding Services">
<meta itemprop="description" content="Looking for a cost estimate for your logo? We have over 16 years experience in developing creative logo designs. For a price quote, visit our page">
<meta itemprop="image" content="http://www.niyati.com/images-og/niyati.jpg">
<meta property="og:type" content="website">
<meta property="og:url" content="http://www.niyati.com">
<meta property="og:site_name" content="Niyati Technologies Private Limited">
<meta property="og:title" content="Looking for a cost estimate for your logo? We have over 16 years experience in developing creative logo designs. For a price quote, visit our page.">
<meta property="fb:app_id" content="246618868710513">
<meta property="og:author" content="Niyati Technologies Private Limited">
<meta property="og:image" content="http://www.niyati.com/images-og/niyati.jpg">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:site" content="@niyati">
<meta name="twitter:creator" content="@rameshnair">
<meta name="twitter:title" content="Logo Design Cost, Logo Design Price Estimate, Branding Services">
<meta name="twitter:description" content="Looking for a cost estimate for your logo? We have over 16 years experience in developing creative logo designs. For a price quote, visit our page.">
<meta name="twitter:image" content="http://www.niyati.com/images-og/niyati.jpg">
<link rel="icon" href="favicon.ico" type="image/x-icon">
<link rel="publisher" href="https://plus.google.com/108457016694924690321">
<link rel="author" href="https://plus.google.com/106449286389499114213">
<link rel="canonical" href="http://www.niyati.com/logo-design-cost.php">
<script type="application/ld+json">
     { "@context" : "http://schema.org",
       "@type" : "Organization",
       "name" : "Niyati",
       "logo" : "http://www.niyati.com/images/niyati-technologies-logo.png",
       "url" : "https://www.niyati.com/",
       "sameAs" : [ "https://twitter.com/niyati",
                    "https://www.facebook.com/niyatitech",
                    "https://www.linkedin.com/company/niyati-technologies",
                    "https://plus.google.com/108457016694924690321/posts",
                    "https://www.youtube.com/user/niyatitech"]
     }
    </script>
<script type="application/ld+json">
{ "@context" : "http://schema.org",
  "@type" : "Organization",
  "url" : "http://www.niyati.com",
  "contactPoint" : [
    { "@type" : "ContactPoint",
      "telephone" : "+91-44-28412639",
      "contactType" : "Customer Service"
    } ] }
</script>
<script>
function test(a)
{
		document.getElementById("sel_1").selectedIndex = a;
		document.getElementById("get_logo").style.display="block";
}
</script>
</head>
<body>
<!-- Google Tag Manager -->
<noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-TZB33S"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-TZB33S');</script>
<!-- End Google Tag Manager -->
<div id="wrapper">
  <header class="header-inner">
    <div class="container">
      <nav class="navbar yamm navbar-fixed-top">
        <div class="container">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle toggle-menu menu-right push-body" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
            <a class="navbar-brand" href="http://www.niyati.com"><img src="images/logo-inner.png" alt="Website Design India" width="121" height="34"></a> </div>
          <div class="get-free-quote">
            <div class="smoothmenu" id="smoothmenu1">
              <ul>
                <li><a href="web-design-cost.htm">Request Proposal</a>
                  <ul>
                    <li><a href="web-design-cost.htm">Web Design</a></li>
                    <li><a href="logo-design-cost.php">Logo Design</a></li>
                    <li><a href="mobile-app-cost.htm">Mobile Apps</a></li>
                    <li><a href="general-enquiries.htm">General Enquiries</a></li>
                  </ul>
                </li>
              </ul>
            </div>
          </div>
          <div class="collapse navbar-collapse cbp-spmenu cbp-spmenu-vertical cbp-spmenu-right" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-left">
              <li><a href="http://www.niyati.com">Home</a></li>
              <li class="dropdown"><a href="services.htm" class="dropdown-toggle" data-toggle="dropdown">Services</a>
                <ul class="dropdown-menu">
                  <li>
                    <div class="menu-content">
                      <div class="row">
                        <ul class="column1 list-unstyled">
                          <h4>Mobility Solutions</h4>
                          <li><a href="enterprise-mobile-apps.htm">Enterprise Apps</a></li>
                          <li><a href="mobile-app-development.htm">Mobile App Development</a></li>
                          <li><a href="m-commerce.htm">M-Commerce</a></li>
                        </ul>
                        <ul class="column list-unstyled">
                          <h4>Web Solutions</h4>
                          <li><a href="application-development.htm">Application Development</a>
                            <ul>
                              <li><a href="application-management-migration.htm">Application Management &amp; Migration</a></li>
                              <li><a href="content-management-system.htm">Content Management System</a></li>
                              <li><a href="digital-asset-management.htm">Digital Asset Management</a></li>
                            </ul>
                          </li>
                          <li><a href="website-design.htm">Website Design</a></li>
                          <li><a href="e-commerce-services.htm">E-Commerce</a></li>
                        </ul>
                        <ul class="column1 list-unstyled">
                          <h4>Digital Solutions</h4>
                          <li><a href="digital-marketing.htm">Digital Marketing</a>
                            <ul>
                              <li><a href="search-engine-optimization.htm">Search Engine Optimization</a></li>
                            </ul>
                          </li>
                          <h4>UI/UX</h4>
                          <li><a href="user-interface-design.htm">User Interface Design</a></li>
                          <!-- <li><a href="user-experience-design.htm">Mobile UI/UX</a></li>-->
                        </ul>
                        <ul class="column1 list-unstyled">
                          <h4>Branding &amp; Creative</h4>
                          <li><a href="logo-design.htm">Branding / Logo Design</a></li>
                          <li><a href="brand-naming.htm">Brand Naming</a></li>
                          <li><a href="explainer-videos.htm">Videos &amp; Animations</a></li>
                        </ul>
                      </div>
                    </div>
                  </li>
                </ul>
              </li>
              <li class="dropdown"><a href="website-portfolio" class="dropdown-toggle" data-toggle="dropdown">Our Work</a>
                <ul class="dropdown-menu menu-width">
                  <div class="menu-content">
                    <li><a href="website-portfolio">Website Design</a></li>
                    <li><a href="app-portfolio">App Development</a></li>
                    <li><a href="uidesign-portfolio">UI Design</a></li>
                    <li><a href="logo-portfolio">Logo Design</a></li>
                    <li><a href="multimedia-portfolio">Multimedia</a></li>
                  </div>
                </ul>
              </li>
              <li class="dropdown"><a href="about.htm" class="dropdown-toggle" data-toggle="dropdown">About Us</a>
                <ul class="dropdown-menu menu-width">
                  <div class="menu-content">
                    <li><a href="about.htm">About Us</a></li>
                    <li><a href="case-studies.htm">Case Studies</a></li>
                    <li><a href="careers.htm">Careers</a></li>
                  </div>
                </ul>
              </li>
              <li><a href="contact.htm">Contact Us</a></li>
              <li><a href="http://www.niyati.com/blog" target="_blank">Blog</a></li>
            </ul>
          </div>
        </div>
      </nav>
    </div>
  </header>
  <div class="inner-container">
    <div class="logo-price-sec">
      <div class="container">
        <div class="row">
          <h1>Logo Design Cost Estimate</h1>
          <br>
          <div class="font-28">We are excited that you decided to contact us for your logo design cost estimation.</div>
        </div>
      </div>
    </div>
  </div>
  <!--<div class="recent-logo-sec bg-white">
    <div class="container">
      <div class="row">
        <div class="logo-price-main">
          <div class="col-sm-4">
            <div class="logo-pricing-in">
<div class="logo-pricing-grey-tile"><span class="price-head">Basic</span><br>
                <br>
                Ideal for startup companies<br>
                and individuals<br>
                <div class="price-head2">15,000</div>
                US $450<br>
                <br>
                <br>
                <a href="#logo-form" onClick="test(1);" class="get-started">Get Started</a> </div>
              <div class="brdr-text">3 custom designs</div>
              <div class="brdr-text">1 round of  revisions </div>
              <div class="tick-brdr-text">
                <div class="grn-tick">Jpeg, Tiff, EPS formats</div>
              </div>
              <div class="involver-text">Graphic designer </div>
              <div class="brdr-text">2 business days<br>
              </div>
            </div>
          </div>
          <div class="col-sm-4">
            <div class="logo-pricing-in">
<div class="logo-pricing-grey-tile-mid"><span class="price-head">Medium</span><br>
                <br>
                Ideal for medium sized <br>
                companies<br>
                <div class="price-head2">30,000</div>
                USD 700</span><br>
                <br>
                <br>
                <a href="#logo-form" onClick="test(2);" class="get-started">Get Started</a></div>
              <div class="brdr-text">5 custom designs</div>
              <div class="brdr-text">2 round of  revisions</div>
              <div class="tick-brdr-text">
                <div class="grn-tick">Jpeg, Tiff, EPS formats</div>
                <div class="grn-tick">Business card and Letterhead templates</div>
              </div>
              <div class="involver-text">Graphic designer and<br>
                Creative director </div>
              <div class="brdr-text">3 business days<br>
              </div>
            </div>
          </div>
          <div class="col-sm-4">
            <div class="logo-pricing-in">
<div class="logo-pricing-grey-tile"><span class="price-head">Complete</span><br>
                <br>
                Ideal for established corporate <br>
                companies<br>
                <div class="price-head2">45,000</div>
                USD 1200<br>
                <br>
                <br>
                <a href="#logo-form" onClick="test(3);" class="get-started">Get Started</a></div>
              <div class="brdr-text">5 custom designs</div>
              <div class="brdr-text">4 round of  revisions</div>
              <div class="tick-brdr-text">
                <div class="grn-tick">Jpeg, Tiff, EPS formats</div>
                <div class="grn-tick">Business card  and letterhead templates</div>
                <div class="grn-tick">PowerPoint Templates</div>
                <div class="grn-tick">Word Templates</div>
              </div>
              <div class="involver-text">Graphic designer, <br>
                Creative director and<br>
                Senior Art Director</div>
              <div class="brdr-text">7 business days<br>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>--><a name="logo-form"></a>
  <div class="logo-form-sec">
    <div class="container">
      <div class="row">Please provide us your details so that we can mail you our logo design price packages.
                <div class="logo-form-sec-pad" id='get_logo'>
          <form name="frmdiscuss" method="post" action="logo_pricing_action.php" class="genral_enq_form"  onSubmit="return logovalid();" >
            <div class="row"><br>
              <br>
              <!--<div class="col-sm-6">
                <select id="sel_1" name="sel_1" class="field-bg-drop">
                  <option value="0" selected="selected">Select</option>
                  <option value="1">Starter Package - $450</option>
                  <option value="2">Medium Package - $700</option>
                  <option value="3">Corporate Package - $1200</option>
                </select>
              </div>-->
              <div class="group col-sm-6">
                <input name="ld_name" class="contact-field" type="text" id="ld_name" onKeyPress="return alpha(event);"/>
                <span class="highlight"></span><span class="bar"></span>
                <label>Name</label>
              </div>
              <div class="group col-sm-6">
                <input name="ld_email" class="contact-field" type="text" id="ld_email"/>
                <span class="highlight"></span><span class="bar"></span>
                <label>Email</label>
              </div>
            </div>
            <div class="row">
              <div class="group col-sm-6">
                <input name="ld_phone" class="contact-field" type="text" id="ld_phone" onKeyPress="return phonenumcheck(event);"/>
                <span class="highlight"></span><span class="bar"></span>
                <label>Phone</label>
              </div>
              <div class="group col-sm-6">
                <input name="ld_city" class="contact-field" type="text" id="ld_city"/>
                <span class="highlight"></span><span class="bar"></span>
                <label>City</label>
              </div>
            </div>
            <!--  <div class="price-lable">
                    <input name="ld_city" type="text" class="field-logo-price" id="ld_city" placeholder="City" onKeyPress="return charactercheck(event);"/>
                  </div>-->
            <div class="hide-row">
              <input name="frm_comment"  type="text" id="frm_comment"  onFocus="clearText(this)" onBlur="clearText(this)" onKeyPress="return numcheck(event);" />
            </div>
            <div class="row">
              <div class="group col-sm-12">
                <textarea name="msg" rows="4" class="contact-txt-area-field" id="msg" ></textarea>
                <span class="highlight"></span><span class="bar"></span>
                <label>Message</label>
              </div>
            </div>
            <br>
            <div class="row">
            <div class="col-sm-6">
                      <div class="g-recaptcha" data-sitekey="6Lez1f8SAAAAAAsI20jQHWLNMz1MhMQMftn8sgh7"></div>
                    </div>
             
              <div class="col-sm-6">
                <div class="pull-right"><small> (All fields are mandatory)</small></div>
              </div>
              </div><br>
               <div class="row"><div class="col-sm-6">
                <input type="submit" name="Submit" id="Submit" value="Submit">
              </div></div>
            </div>
          </form>
        </div>
              </div>
    </div>
  </div>
  <div class="recent-logo-sec">
    <div class="container">
      <div class="row">
        <h1>Some of our recent logo design works</h1>
        <div class="recent-logo-pad">
          <div class="recent-logo col-xm-2 nopadding"><img src="images/logo-design-connect.gif" alt="" width="420" height="327" class="img-responsive"></div>
          <div class="recent-logo col-xm-2 nopadding"><img src="images/logo-design-asianart.gif" alt="" width="420" height="327" class="img-responsive"></div>
          <div class="recent-logo col-xm-2 nopadding"><img src="images/logo-design-graviton.gif" alt="" width="420" height="327" class="img-responsive"></div>
          <div class="recent-logo col-xm-2 nopadding"><img src="images/logo-design-carefinder.gif" alt="" width="420" height="327" class="img-responsive"></div>
          <div class="recent-logo col-xm-2 nopadding"><img src="images/logo-design-lumiere.gif" alt="" width="420" height="327" class="img-responsive"></div>
          <div class="recent-logo col-xm-2 nopadding"><img src="images/logo-design-face.gif" alt="" width="420" height="327" class="img-responsive"></div>
        </div>
      </div>
      <div class="row">
        <h1><a href="http://www.niyati.com/logo-portfolio">View Logo Portfolio</a></h1>
      </div>
    </div>
  </div>
  <div class="project-discussion-sec">
    <div class="container">
      <div class="row proj-disc-pad">
        <div class="col-lg-12">
          <h1>Initiate a project discussion with us:</h1>
          <br>
          <div class="mail-phone"><a href="mailto:contact@niyati.com"><img src="images/icon-mail.gif" alt="" width="35" height="26">contact@niyati.com</a> <span><img src="images/icon-phone.png" width="24" height="29" alt=""> 91-98840 82639</span> <a href="skype:niyatitech?add"><img src="images/icon-skype.png" width="32" height="32" alt="">niyatitech</a></div>
        </div>
      </div>
    </div>
  </div>
  <div class="location-sec">
    <div class="container">
      <div class="row">
        <div class="social">
          <div data-wow-delay="0.5s" class="col-xs-2 wow fadeIn"><a href="http://www.facebook.com/niyatitech" target="_blank" class="facebook"></a></div>
          <div data-wow-delay="0.8s" class="col-xs-2 wow fadeIn"><a href="http://www.twitter.com/niyati" target="_blank" class="twitter"></a></div>
          <div data-wow-delay="1.1s" class="col-xs-2 wow fadeIn"><a href="https://www.linkedin.com/company/niyati-technologies" target="_blank" class="linked"></a></div>
          <div data-wow-delay="1.4s" class="col-xs-2 wow fadeIn"><a href="https://plus.google.com/+Niyati" target="_blank" class="google"></a></div>
          <div data-wow-delay="1.7s" class="col-xs-2 wow fadeIn"><a href="https://www.instagram.com/niyatitech/" target="_blank" class="pinterest"></a></div>
          <div data-wow-delay="2.0s" class="col-xs-2 wow fadeIn"><a href="http://www.niyati.com/blog/" target="_blank" class="blog"></a> </div>
        </div>
      </div>
    </div>
  </div>
  <footer>
    <div class="container">
      <div class="row hidden-xs">
        <div class="col-sm-6 col-md-3">
          <div class="col-xs-2"><a href="enterprise-mobile-apps.htm" title="Mobility Solutions" class="icon-app-dev"></a></div>
          <div class="col-xs-10"><a href="enterprise-mobile-apps.htm" class="h5">Mobility Solutions</a><br>
            <br>
            <ul>
              <li><a href="enterprise-mobile-apps.htm">Enterprise Apps</a></li>
              <li><a href="mobile-app-development.htm">Mobile App Development</a></li>
              <li><a href="m-commerce.htm">M-Commerce</a></li>
            </ul>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="col-xs-2"><a href="application-development.htm" title="Web Solutions" class="icon-web-dev"></a></div>
          <div class="col-xs-10"><a href="application-development.htm" class="h5">Web Solutions</a><br>
            <br>
            <ul>
              <li><a href="application-development.htm">Application Development</a></li>
              <li><a href="website-design.htm">Website Design </a></li>
              <li><a href="e-commerce-services.htm">E-Commerce</a></li>
            </ul>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="col-xs-2"><a href="digital-marketing.htm" title="UI/UX" class="icon-ui-dev"></a></div>
          <div class="col-xs-10"><a href="digital-marketing.htm" class="h5">Digital Solutions</a><br>
            <br>
            <ul>
              <li><a href="digital-marketing.htm">Digital Marketing</a></li>
              <li><a href="search-engine-optimization.htm">Search Engine Optimization</a></li>
            </ul>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="col-xs-2"><a href="logo-design.htm" title="Ecommerce" class="icon-ecom-dev"></a></div>
          <div class="col-xs-10"><a href="logo-design.htm" class="h5">Branding &amp; Creative</a><br>
            <br>
            <ul>
              <li><a href="logo-design.htm">Branding / Logo Design</a></li>
              <li><a href="explainer-videos.htm">Explainer Videos</a></li>
              <li><a href="user-interface-design.htm">User Interface Design</a></li>
            </ul>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="copyright">&copy; <script type="text/javascript">
var now = new Date();
var d = now.getFullYear();
document.write(d);</script> Niyati Technologies Private Limited. All rights reserved.<br>
          <ul>
            <li><a href="about.htm">About Us</a></li>
            <li><a href="sitemap.htm">Sitemap</a></li>
            <li><a href="contact.htm">Contact</a></li>
          </ul>
        </div>
      </div>
    </div>
  </footer>
</div>
</div>
<script type="text/javascript" src="includes/validate.js"></script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> 
<script src="includes/isotope.js"></script> 
<script type="text/javascript" src="includes/isotope-script.js"></script> 
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script> 
<script type="text/javascript" src="includes/menu.js"></script> 
<script type="text/javascript" src="includes/jpushmenu.js"></script> 
<!--<script type="text/javascript" src="includes/jv2p.js"></script> 
--><script type="text/javascript">
//<![CDATA[
 $(document).ready(function(){
 $('.toggle-menu').jPushMenu({closeOnClickLink: false});
 $('.dropdown-toggle').dropdown();
 });
//]]>
</script> 
<script>
$('.nav .dropdown-toggle').click(function() {
    var location = $(this).attr('href');
    window.location.href = location;
    return false;
});
$("#sel_1").change(function () {
    if($(this).val() == "0") $(this).addClass("empty");
    else $(this).removeClass("empty")
});
$("#sel_1").change();
</script> 
<script>
$(window, document, undefined).ready(function() {
 $('input').blur(function() {
    var $this = $(this);
    if ($this.val())
      $this.addClass('used');
    else
      $this.removeClass('used');
  });
  $('textarea').blur(function() {
    var $this = $(this);
    if ($this.val())
      $this.addClass('used');
    else
      $this.removeClass('used');
  });
  });
</script> 
<script src='https://www.google.com/recaptcha/api.js'></script> 
<!-- Start of StatCounter Code for Default Guide --> 
<script type="text/javascript">

var sc_project=738026; 

var sc_invisible=1; 

var sc_security="b506d3f5"; 

</script> 
<script type="text/javascript"

src="http://www.statcounter.com/counter/counter.js"></script>
<noscript>
<div class="statcounter"><a title="site stats"

href="http://statcounter.com/" target="_blank"><img

class="statcounter"

src="http://c.statcounter.com/738026/0/b506d3f5/1/"

alt="site stats"></a></div>
</noscript>
<!-- End of StatCounter Code for Default Guide --> 
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-27088434-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>
</body>
</html>